Feature: Login functionality for LeafTaps Application

Scenario: Login with positive credentials
Given Launch the Browser and Load the url
When Enter the Username
When Enter the password
When click on Login button
Then HomePage is displayed