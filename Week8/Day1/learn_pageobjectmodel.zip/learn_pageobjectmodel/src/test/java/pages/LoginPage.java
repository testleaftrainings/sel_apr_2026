package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;  

public class LoginPage extends BaseClass {

    public LoginPage(ChromeDriver driver){
        this.driver=driver;
    }

    public LoginPage enteruName(){
        driver.findElement(By.id("username")).sendKeys("democsr2");
       return this;
    }
    public LoginPage enterPword(){
        driver.findElement(By.id("password")).sendKeys("crmsfa");
        return this;
    }
    public WelcomePage clickLogin(){
        driver.findElement(By.className("decorativeSubmit")).click();
        return new WelcomePage(driver);
    }

}
