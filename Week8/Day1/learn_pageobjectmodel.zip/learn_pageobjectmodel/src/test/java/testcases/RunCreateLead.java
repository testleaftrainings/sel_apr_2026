package testcases;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class RunCreateLead extends BaseClass {

    @Test
    public void runCL(){
        //System.out.println("testMethod:"+driver);
        LoginPage lp=new LoginPage(driver);
       lp.enteruName().enterPword().clickLogin().clickCRMSFA().clickLeads().clickCreateLead().enterCname()
       .enterFname().enterLname().clickSubmit().verifyLeads();

    }

}
