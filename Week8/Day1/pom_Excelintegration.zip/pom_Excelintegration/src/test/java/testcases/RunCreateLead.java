package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class RunCreateLead extends BaseClass {
     @BeforeTest
    public void setValues(){
        excelFileName="CreateLead";
    }

    @Test(dataProvider="fetchData")
    public void runCL(String uName,String pwd,String cName,String fName,String lName){
        //System.out.println("testMethod:"+driver);
        LoginPage lp=new LoginPage(driver);
       lp.enteruName(uName).enterPword(pwd).clickLogin().clickCRMSFA().clickLeads().clickCreateLead().enterCname(cName)
       .enterFname(fName).enterLname(lName).clickSubmit().verifyLeads();

    }

}
