package pages;

import base.BaseClass;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class ViewLeadsPage extends BaseClass {

    public ViewLeadsPage(ChromeDriver driver) {
        this.driver=driver;
    }

    public void verifyLeads(){
        String text=driver.findElement(By.id("viewLead_firstName_sp")).getText();
        if(text.contains("Saranya")){
            System.out.println("Leads are created");

        }else{
            System.out.println("Leads are not created");
        }
    }

}
