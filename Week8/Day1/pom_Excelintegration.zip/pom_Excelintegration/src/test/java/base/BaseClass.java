package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import utils.ReadExcel;

public class BaseClass {
    public ChromeDriver driver;
    public String excelFileName;


    @DataProvider(name="fetchData")
    public String[][] sendData()throws IOException{
        return ReadExcel.readData(excelFileName);
    }
    
    @BeforeMethod
    public void preConditions(){
        driver=new ChromeDriver();
        System.out.println("BeforeMethod:"+driver);
        driver.get("https://leaftaps.com/opentaps/control/main");
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

    }
    @AfterMethod
    public void postConditions(){
        driver.close();
    }

}
