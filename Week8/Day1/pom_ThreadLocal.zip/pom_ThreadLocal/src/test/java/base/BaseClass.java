package base;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import io.cucumber.testng.AbstractTestNGCucumberTests;

public class BaseClass extends AbstractTestNGCucumberTests {
    //public static ChromeDriver driver;

    private static final ThreadLocal<ChromeDriver> cDriver=new ThreadLocal<ChromeDriver>();

    public void setDriver(){
        cDriver.set(new ChromeDriver());
    }
    public ChromeDriver getDriver(){
        return cDriver.get();
    }
    
    @BeforeMethod
    public void preConditions(){
       // driver=new ChromeDriver();
       // System.out.println("BeforeMethod:"+driver);
       setDriver();
        getDriver().get("https://leaftaps.com/opentaps/control/main");
        getDriver().manage().window().maximize();
        getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

    }
    @AfterMethod
    public void postConditions(){
        getDriver().close();
    }

}
