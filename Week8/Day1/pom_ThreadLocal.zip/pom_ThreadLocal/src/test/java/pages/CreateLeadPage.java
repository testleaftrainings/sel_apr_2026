package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class CreateLeadPage extends BaseClass {

    @When("Enter the companyName (.*)$")
    public CreateLeadPage enterCname(String cName){
        getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
        return this;
    }
    @When("Enter the firstName (.*)$")
    public CreateLeadPage enterFname(String fName){
        getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
        return this;
    }
    @When("Enter the lastName (.*)$")
    public CreateLeadPage enterLname(String lName){
        getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
        return this;
    }
    @And("Click on SubmitButton")
    public ViewLeadsPage clickSubmit(){
        getDriver().findElement(By.name("submitButton")).click();
        return new ViewLeadsPage();

    }

}
