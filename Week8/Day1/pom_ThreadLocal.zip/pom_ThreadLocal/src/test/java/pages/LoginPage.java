package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;  
import io.cucumber.java.en.When;

public class LoginPage extends BaseClass {

    
    @When("Enter the Username {string}")
    public LoginPage enteruName(String uName){
        getDriver().findElement(By.id("username")).sendKeys(uName);
       return this;
    }
    @When("Enter the password {string}")
    public LoginPage enterPword(String pwd){
        getDriver().findElement(By.id("password")).sendKeys(pwd);
        return this;
    }
    @When("click on Login button")
    public WelcomePage clickLogin(){
        getDriver().findElement(By.className("decorativeSubmit")).click();
        return new WelcomePage();
    }

}
